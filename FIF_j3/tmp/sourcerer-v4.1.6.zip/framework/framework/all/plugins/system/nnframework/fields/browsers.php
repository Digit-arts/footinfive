<?php
defined('_JEXEC') or die;

// For backwards compatibility
require_once __DIR__ . '/agents.php';
class JFormFieldNN_Browsers extends JFormFieldNN_Agents
{
}
