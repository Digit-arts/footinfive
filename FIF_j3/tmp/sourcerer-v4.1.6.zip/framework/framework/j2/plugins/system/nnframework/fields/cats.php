<?php
defined('_JEXEC') or die;

// For backwards compatibility
require_once __DIR__ . '/content.php';
class JFormFieldNN_Cats extends JFormFieldNN_Content
{
}
