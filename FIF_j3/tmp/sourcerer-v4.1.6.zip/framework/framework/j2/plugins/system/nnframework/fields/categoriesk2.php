<?php
defined('_JEXEC') or die;

// For backwards compatibility
require_once __DIR__ . '/k2.php';
class JFormFieldNN_CategoriesK2 extends JFormFieldNN_K2
{
}
