<?php
defined('_JEXEC') or die('access deny');
echo "test publipostage";
?>